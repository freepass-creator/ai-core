export const man = (n) => {
    const v = Number(n);
    return v ? `${Math.round(v / 10000).toLocaleString()}만` : '0';
};
export function manWon(n) {
    const v = Math.max(0, Math.round(Number(n) || 0));
    if (!v)
        return '0원';
    const m = Math.floor(v / 10000);
    const rest = v % 10000;
    if (!m)
        return `${v.toLocaleString()}원`;
    return rest ? `${m.toLocaleString()}만 ${rest.toLocaleString()}원` : `${m.toLocaleString()}만원`;
}
export function manShort(n, opts) {
    const v = Math.max(0, Math.floor(Number(n) || 0));
    if (!v)
        return '0원';
    if (v < 10000)
        return `${v.toLocaleString('ko-KR')}원`;
    const man = v / 10000;
    if (opts?.decimal) {
        const cut = Math.floor(man * 10) / 10;
        const text = Number.isInteger(cut) ? String(cut) : cut.toFixed(1);
        return `${Number(text).toLocaleString('ko-KR')}만원`;
    }
    return `${Math.floor(man).toLocaleString('ko-KR')}만원`;
}
export function kmDisplay(raw) {
    const source = String(raw ?? '').trim();
    if (!source)
        return '';
    const normalized = source.replace(/,/g, '').replace(/\s*km\s*$/i, '').trim();
    const value = Number(normalized);
    if (Number.isFinite(value) && value >= 0)
        return `${value.toLocaleString('ko-KR')}km`;
    return source;
}
export function isEvFuel(fuel) {
    return /전기|EV|이브이/i.test(String(fuel ?? ''));
}
export function kmValue(raw) {
    const s = String(raw ?? '').trim().replace(/,/g, '');
    if (!s || /^[-–—.]+$/.test(s))
        return 0;
    const man = s.match(/^([\d.]+)\s*만\s*(?:km|킬로)?$/i);
    if (man && Number.isFinite(Number(man[1])))
        return Math.round(Number(man[1]) * 10_000);
    const plain = s.match(/^([\d.]+)\s*(?:km|킬로)?$/i);
    if (plain && Number.isFinite(Number(plain[1])))
        return Math.round(Number(plain[1]));
    const digits = s.replace(/[^\d.]/g, '');
    return digits && Number.isFinite(Number(digits)) ? Math.round(Number(digits)) : 0;
}
export function fileSizeText(n) {
    if (!Number.isFinite(n) || n <= 0)
        return '';
    return n >= 1048576 ? `${(n / 1048576).toFixed(1)}MB` : `${Math.max(1, Math.round(n / 1024))}KB`;
}
export function ymdDisplay(raw) {
    const src = String(raw ?? '').trim();
    if (!src)
        return '';
    const m = src.match(/^(\d{2,4})\s*[-./년]\s*(\d{1,2})\s*[-./월]\s*(\d{1,2})\s*일?$/)
        || src.match(/^(\d{4})(\d{2})(\d{2})$/);
    if (!m)
        return src;
    let y = Number(m[1]);
    const mo = Number(m[2]);
    const d = Number(m[3]);
    if (m[1].length <= 2)
        y = y >= 70 ? 1900 + y : 2000 + y;
    if (y < 1900 || y > 2100 || mo < 1 || mo > 12 || d < 1 || d > 31)
        return src;
    return `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}
export function msgClock(ms, opts) {
    const n = Number(ms);
    if (!n)
        return '';
    const d = new Date(n);
    const hm = d.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', hour12: false });
    const now = new Date();
    if (d.toDateString() === now.toDateString())
        return hm;
    const md = `${d.getMonth() + 1}/${d.getDate()}`;
    return opts?.dateOnly ? md : `${md} ${hm}`;
}
