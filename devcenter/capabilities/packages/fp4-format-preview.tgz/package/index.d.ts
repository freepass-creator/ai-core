export declare function kmValue(raw: unknown): number;
export declare function fileSizeText(n: number): string;