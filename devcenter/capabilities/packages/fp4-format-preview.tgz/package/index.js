export {kmValue,fileSizeText} from './source.js';
